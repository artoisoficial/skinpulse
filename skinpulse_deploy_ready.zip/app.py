print('SkinPulse backend placeholder rodando...')
